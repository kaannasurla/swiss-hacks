package ch.juliusbaer.daybreak.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ch.juliusbaer.daybreak.data.Article
import ch.juliusbaer.daybreak.ui.components.Caption
import ch.juliusbaer.daybreak.ui.components.Chip
import ch.juliusbaer.daybreak.ui.components.PrimaryButton
import ch.juliusbaer.daybreak.ui.theme.Accent
import ch.juliusbaer.daybreak.ui.theme.AccentSoft
import ch.juliusbaer.daybreak.ui.theme.Ink
import ch.juliusbaer.daybreak.ui.theme.InkSecondary

@Composable
fun ArticleScreen(article: Article, onDiscuss: () -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 22.dp)
            .padding(top = 12.dp, bottom = 28.dp)
    ) {
        Chip(article.tag, bg = AccentSoft, fg = Accent)
        Spacer(Modifier.height(14.dp))
        Text(
            article.headline,
            color = Ink,
            fontSize = 22.sp,
            fontWeight = FontWeight.Medium,
            lineHeight = 29.sp
        )
        Spacer(Modifier.height(8.dp))
        Caption(article.byline)
        Spacer(Modifier.height(18.dp))
        article.body.forEach { para ->
            Text(para, color = InkSecondary, fontSize = 15.sp, lineHeight = 24.sp)
            Spacer(Modifier.height(14.dp))
        }
        Spacer(Modifier.height(8.dp))
        PrimaryButton("Discuss with Marco", onClick = onDiscuss)
    }
}
