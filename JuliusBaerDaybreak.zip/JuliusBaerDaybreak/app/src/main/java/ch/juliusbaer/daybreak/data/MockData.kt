package ch.juliusbaer.daybreak.data

/**
 * Static sample data for the prototype. In production this layer would be a
 * repository backed by the bank's portfolio, FX, CRM, and research services.
 */

data class Allocation(val label: String, val percent: Int)
data class Wallet(val code: String, val name: String, val balance: String, val symbol: String)
data class QuickRequest(val title: String)
data class ChatBubble(val text: String, val fromClient: Boolean)
data class Recipient(val name: String, val detail: String, val initials: String)
data class CardTx(val merchant: String, val location: String, val amount: String, val pending: Boolean)
data class Article(
    val tag: String,
    val headline: String,
    val dek: String,
    val time: String,
    val byline: String,
    val body: List<String>
)

object MockData {

    // Client / header
    const val clientName = "Elena"
    const val clientFull = "Elena Vasari"
    const val clientInitials = "EV"
    const val clientSince = "Client since 2014"
    const val dateLabel = "Friday, 19 June"
    const val location = "Zürich"

    // Wealth
    const val totalWealth = "CHF 24,612,840"
    const val overnightChange = "+184,200 · 0.76%"
    const val yearChange = "+1,284,600 this year · 5.5%"

    val sparkline = listOf(22f, 18f, 21f, 12f, 15f, 7f, 9f, 4f).map { 30f - it }

    val wealthSeries = listOf(
        21.0f, 21.4f, 20.9f, 22.1f, 22.6f, 22.3f,
        23.0f, 23.4f, 23.1f, 23.9f, 24.3f, 24.61f
    )

    val allocations = listOf(
        Allocation("Equities", 42),
        Allocation("Fixed income", 28),
        Allocation("Alternatives", 19),
        Allocation("Cash & FX", 11)
    )

    // Move
    val wallets = listOf(
        Wallet("CHF", "Swiss franc", "1,240,000", "CHF"),
        Wallet("USD", "US dollar", "860,400", "$"),
        Wallet("EUR", "Euro", "410,000", "€"),
        Wallet("JPY", "Japanese yen", "12,400,000", "¥")
    )

    const val tripCity = "Tokyo"
    const val tripWhen = "in 2 days"
    const val tripCurrency = "¥ 12,400,000 already waiting"

    const val convertFrom = "CHF 50,000"
    const val convertTo = "¥ 8.62M"
    const val convertRate = "1 CHF = 172.4 ¥"

    // Send money
    val recipients = listOf(
        Recipient("Marco Brunner", "Internal · current account", "MB"),
        Recipient("Atelier Voss AG", "CH93 •••• 4810", "AV"),
        Recipient("Sofia Vasari", "IT60 •••• 2210", "SV"),
        Recipient("Hotel Okura Tokyo", "JP •••• 7745", "HO")
    )

    // Card
    const val cardHolder = "Elena Vasari"
    const val cardNumber = "•••• •••• •••• 4417"
    const val cardExpiry = "08 / 28"
    const val cardLimit = "CHF 50,000 / month"

    val cardTransactions = listOf(
        CardTx("Kronenhalle", "Zürich", "CHF 480", false),
        CardTx("Globus", "Zürich", "CHF 1,240", false),
        CardTx("Hotel Okura", "Tokyo", "¥ 62,000", true)
    )

    // Concierge
    const val rmName = "Marco Brunner"
    const val rmRole = "Relationship manager · Zürich"
    const val rmInitials = "MB"

    val thread = listOf(
        ChatBubble("Morning Elena — your yen is loaded for Tokyo. Want me to arrange a car at Haneda?", false),
        ChatBubble("Yes please, and a dinner reservation Thursday.", true)
    )

    val requests = listOf(
        QuickRequest("Arrange JPY cash in Tokyo"),
        QuickRequest("Set up an FX forward"),
        QuickRequest("Schedule a portfolio review")
    )

    // Insights / research feed (original sample prose, not from any source)
    val insights = listOf(
        Article(
            tag = "Currencies",
            headline = "The franc held firm against the dollar overnight",
            dek = "What a steady CHF means for your unhedged dollar sleeve.",
            time = "06:40",
            byline = "Research desk · 19 June",
            body = listOf(
                "The Swiss franc was broadly unchanged against the dollar in overnight trading, leaving the franc value of your US holdings effectively flat.",
                "For clients with meaningful unhedged dollar exposure, periods of currency calm are a good moment to review whether the hedge ratio still matches the spending plan for the year ahead.",
                "Marco has flagged one small rebalancing idea that would trim the dollar sleeve by a few points and move the proceeds into short-dated franc instruments. It is a modest adjustment, not a call on the currency.",
                "As always, nothing here is a recommendation to act before discussing it together."
            )
        ),
        Article(
            tag = "Equities",
            headline = "Quality dividends are quietly back in favour",
            dek = "Why steady compounders are leading this leg of the rally.",
            time = "Yesterday",
            byline = "Research desk · 18 June",
            body = listOf(
                "After a long stretch where growth names led, investors have rotated toward companies with durable cash flows and a habit of returning capital.",
                "Your portfolio already carries a healthy weight in this style, which is part of why the equity sleeve has held up well through recent volatility.",
                "We are not suggesting chasing the move. The point is simply that the part of the market doing the work right now is the part you are already positioned in."
            )
        ),
        Article(
            tag = "Travel",
            headline = "Spending abroad: a note before Tokyo",
            dek = "Your yen is pre-positioned — here is how the card will behave.",
            time = "Yesterday",
            byline = "Client service · 18 June",
            body = listOf(
                "Your travel card will draw from your yen wallet automatically once you land, so purchases in Tokyo settle in local currency with no conversion at the till.",
                "If a merchant offers to charge you in francs, decline it — paying in the local currency uses our rate rather than theirs.",
                "Concierge can arrange cash on arrival if you would like some yen in hand before reaching the hotel."
            )
        )
    )
}
