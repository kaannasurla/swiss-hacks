package ch.juliusbaer.daybreak.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.KeyboardArrowRight
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ch.juliusbaer.daybreak.data.Allocation
import ch.juliusbaer.daybreak.ui.theme.Accent
import ch.juliusbaer.daybreak.ui.theme.AccentSoft
import ch.juliusbaer.daybreak.ui.theme.Hairline
import ch.juliusbaer.daybreak.ui.theme.Ink
import ch.juliusbaer.daybreak.ui.theme.InkSecondary
import ch.juliusbaer.daybreak.ui.theme.InkTertiary
import ch.juliusbaer.daybreak.ui.theme.SurfaceMuted
import ch.juliusbaer.daybreak.ui.theme.SurfaceWhite

/** White card with a 0.5dp hairline border. Optionally clickable. */
@Composable
fun JbCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    content: @Composable () -> Unit
) {
    val base = modifier
        .fillMaxWidth()
        .clip(RoundedCornerShape(16.dp))
        .background(SurfaceWhite)
        .border(0.7.dp, Hairline, RoundedCornerShape(16.dp))
    val clickable = if (onClick != null) base.clickable { onClick() } else base
    Box(clickable.padding(16.dp)) { content() }
}

/** Soft muted card with no border. Optionally clickable. */
@Composable
fun SoftCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    content: @Composable () -> Unit
) {
    val base = modifier
        .fillMaxWidth()
        .clip(RoundedCornerShape(16.dp))
        .background(SurfaceMuted)
    val clickable = if (onClick != null) base.clickable { onClick() } else base
    Box(clickable.padding(16.dp)) { content() }
}

@Composable
fun Chip(
    text: String,
    bg: Color = SurfaceMuted,
    fg: Color = InkSecondary,
    modifier: Modifier = Modifier
) {
    Box(
        modifier
            .clip(RoundedCornerShape(20.dp))
            .background(bg)
            .padding(horizontal = 11.dp, vertical = 5.dp)
    ) {
        Text(text, color = fg, fontSize = 12.sp)
    }
}

@Composable
fun Caption(text: String, color: Color = InkTertiary, modifier: Modifier = Modifier) {
    Text(text, color = color, fontSize = 12.sp, modifier = modifier)
}

@Composable
fun SectionLabel(text: String) {
    Text(text, color = Ink, fontSize = 13.sp, fontWeight = FontWeight.Medium)
}

/** Filled accent button — the primary call to action. */
@Composable
fun PrimaryButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true
) {
    Box(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(if (enabled) Accent else SurfaceMuted)
            .clickable(enabled = enabled) { onClick() }
            .padding(vertical = 15.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text,
            color = if (enabled) SurfaceWhite else InkTertiary,
            fontSize = 15.sp,
            fontWeight = FontWeight.Medium
        )
    }
}

/** A circular initials avatar. */
@Composable
fun Avatar(
    initials: String,
    size: Dp = 46.dp,
    bg: Color = AccentSoft,
    fg: Color = Accent,
    onClick: (() -> Unit)? = null
) {
    val base = Modifier.size(size).clip(CircleShape).background(bg)
    val clickable = if (onClick != null) base.clickable { onClick() } else base
    Box(clickable, contentAlignment = Alignment.Center) {
        Text(initials, color = fg, fontWeight = FontWeight.Medium, fontSize = (size.value / 3).sp)
    }
}

/** Generic settings/list row: leading icon, title, optional subtitle/value, chevron. */
@Composable
fun ListRow(
    title: String,
    subtitle: String? = null,
    valueText: String? = null,
    leading: ImageVector? = null,
    showChevron: Boolean = true,
    onClick: (() -> Unit)? = null
) {
    val base = Modifier.fillMaxWidth()
    val clickable = if (onClick != null) base.clickable { onClick() } else base
    Row(
        clickable.padding(vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (leading != null) {
            Icon(leading, contentDescription = null, tint = InkSecondary, modifier = Modifier.size(19.dp))
            Spacer(Modifier.width(12.dp))
        }
        Column(Modifier.weight(1f)) {
            Text(title, color = Ink, fontSize = 14.sp)
            if (subtitle != null) {
                Text(subtitle, color = InkTertiary, fontSize = 12.sp, modifier = Modifier.padding(top = 1.dp))
            }
        }
        if (valueText != null) {
            Text(valueText, color = InkSecondary, fontSize = 13.sp, modifier = Modifier.padding(end = 6.dp))
        }
        if (showChevron) {
            Icon(
                Icons.AutoMirrored.Outlined.KeyboardArrowRight,
                contentDescription = null,
                tint = InkTertiary
            )
        }
    }
}

/** Allocation row with label, percent, and a thin progress bar. */
@Composable
fun AllocationRow(item: Allocation) {
    Column(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(item.label, color = Ink, fontSize = 14.sp)
            Text("${item.percent}%", color = InkSecondary, fontSize = 14.sp)
        }
        Box(
            Modifier
                .padding(top = 6.dp)
                .fillMaxWidth()
                .height(7.dp)
                .clip(RoundedCornerShape(4.dp))
                .background(SurfaceMuted)
        ) {
            Box(
                Modifier
                    .fillMaxWidth(item.percent / 100f)
                    .height(7.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(Accent)
            )
        }
    }
}
