package ch.juliusbaer.daybreak.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentWidth
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.KeyboardArrowRight
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.Call
import androidx.compose.material.icons.outlined.Payments
import androidx.compose.material.icons.outlined.TrendingUp
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ch.juliusbaer.daybreak.data.ChatBubble
import ch.juliusbaer.daybreak.data.MockData
import ch.juliusbaer.daybreak.ui.components.Caption
import ch.juliusbaer.daybreak.ui.components.JbCard
import ch.juliusbaer.daybreak.ui.theme.Accent
import ch.juliusbaer.daybreak.ui.theme.AccentSoft
import ch.juliusbaer.daybreak.ui.theme.Hairline
import ch.juliusbaer.daybreak.ui.theme.Ink
import ch.juliusbaer.daybreak.ui.theme.InkSecondary
import ch.juliusbaer.daybreak.ui.theme.InkTertiary
import ch.juliusbaer.daybreak.ui.theme.SurfaceMuted

@Composable
fun ConciergeScreen() {
    Column(
        Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 22.dp)
            .padding(top = 12.dp, bottom = 24.dp)
    ) {
        // RM card
        JbCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier
                        .size(46.dp)
                        .clip(CircleShape)
                        .background(AccentSoft),
                    contentAlignment = Alignment.Center
                ) {
                    Text(MockData.rmInitials, color = Accent, fontWeight = FontWeight.Medium)
                }
                Spacer(Modifier.width(13.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        MockData.rmName,
                        color = Ink,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Medium
                    )
                    Caption(MockData.rmRole, modifier = Modifier.padding(top = 1.dp))
                }
                Icon(
                    Icons.Outlined.Call,
                    contentDescription = "Call",
                    tint = InkSecondary,
                    modifier = Modifier.size(20.dp)
                )
            }
        }

        Spacer(Modifier.height(16.dp))

        MockData.thread.forEach { bubble ->
            MessageBubble(bubble)
            Spacer(Modifier.height(8.dp))
        }

        Spacer(Modifier.height(10.dp))
        Caption("Quick requests")
        Spacer(Modifier.height(10.dp))

        JbCard {
            Column {
                val icons = listOf(
                    Icons.Outlined.Payments,
                    Icons.Outlined.TrendingUp,
                    Icons.Outlined.CalendarMonth
                )
                MockData.requests.forEachIndexed { i, r ->
                    RequestRow(r.title, icons[i])
                    if (i != MockData.requests.lastIndex) {
                        HorizontalDivider(color = Hairline, thickness = 0.7.dp)
                    }
                }
            }
        }
    }
}

@Composable
private fun MessageBubble(bubble: ChatBubble) {
    val align = if (bubble.fromClient) Alignment.CenterEnd else Alignment.CenterStart
    val bg = if (bubble.fromClient) AccentSoft else SurfaceMuted
    val fg = if (bubble.fromClient) Accent else Ink
    Box(Modifier.fillMaxWidth(), contentAlignment = align) {
        Box(
            Modifier
                .fillMaxWidth(0.8f)
                .wrapContentWidth(if (bubble.fromClient) Alignment.End else Alignment.Start)
                .clip(RoundedCornerShape(14.dp))
                .background(bg)
                .padding(horizontal = 13.dp, vertical = 10.dp)
        ) {
            Text(bubble.text, color = fg, fontSize = 13.sp, lineHeight = 19.sp)
        }
    }
}

@Composable
private fun RequestRow(title: String, icon: ImageVector) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = InkSecondary, modifier = Modifier.size(19.dp))
        Spacer(Modifier.width(11.dp))
        Text(title, color = Ink, fontSize = 13.sp, modifier = Modifier.weight(1f))
        Icon(
            Icons.AutoMirrored.Outlined.KeyboardArrowRight,
            contentDescription = null,
            tint = InkTertiary
        )
    }
}
