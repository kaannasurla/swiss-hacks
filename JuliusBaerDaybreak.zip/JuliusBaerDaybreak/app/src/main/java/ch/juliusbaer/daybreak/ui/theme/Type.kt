package ch.juliusbaer.daybreak.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

// The serif used for monetary figures — evokes a private-bank statement / broadsheet.
// FontFamily.Serif maps to the platform serif (Noto Serif on modern Android).
val SerifNumber = FontFamily.Serif

val AppTypography = Typography(
    headlineSmall = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.Medium,
        fontSize = 21.sp,
        letterSpacing = (-0.2).sp
    ),
    titleMedium = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.Medium,
        fontSize = 16.sp
    ),
    bodyMedium = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.Normal,
        fontSize = 14.sp,
        lineHeight = 21.sp
    ),
    labelMedium = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.Normal,
        fontSize = 12.sp,
        letterSpacing = 0.2.sp
    )
)

// Big wealth figures — used directly where we render balances.
val WealthLarge = TextStyle(
    fontFamily = SerifNumber,
    fontWeight = FontWeight.Normal,
    fontSize = 28.sp,
    letterSpacing = (-0.5).sp,
    color = Ink
)

val WealthMedium = TextStyle(
    fontFamily = SerifNumber,
    fontWeight = FontWeight.Normal,
    fontSize = 16.sp,
    color = Ink
)
