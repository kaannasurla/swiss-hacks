package ch.juliusbaer.daybreak.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.KeyboardArrowRight
import androidx.compose.material.icons.outlined.CreditCard
import androidx.compose.material.icons.outlined.Flight
import androidx.compose.material.icons.outlined.HeadsetMic
import androidx.compose.material.icons.outlined.NorthEast
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material.icons.outlined.SwapHoriz
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ch.juliusbaer.daybreak.data.MockData
import ch.juliusbaer.daybreak.ui.components.Caption
import ch.juliusbaer.daybreak.ui.components.Chip
import ch.juliusbaer.daybreak.ui.components.JbCard
import ch.juliusbaer.daybreak.ui.components.SoftCard
import ch.juliusbaer.daybreak.ui.components.Sparkline
import ch.juliusbaer.daybreak.ui.navigation.Routes
import ch.juliusbaer.daybreak.ui.theme.Accent
import ch.juliusbaer.daybreak.ui.theme.AccentSoft
import ch.juliusbaer.daybreak.ui.theme.Ink
import ch.juliusbaer.daybreak.ui.theme.InkSecondary
import ch.juliusbaer.daybreak.ui.theme.InkTertiary
import ch.juliusbaer.daybreak.ui.theme.SurfaceMuted
import ch.juliusbaer.daybreak.ui.theme.Up
import ch.juliusbaer.daybreak.ui.theme.WealthLarge

@Composable
fun DaybreakScreen(onNavigate: (String) -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 22.dp)
            .padding(top = 8.dp, bottom = 24.dp)
    ) {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Top
        ) {
            Column {
                Text("Good morning, ${MockData.clientName}", color = Ink, fontSize = 21.sp, fontWeight = FontWeight.Medium)
                Caption(MockData.dateLabel, modifier = Modifier.padding(top = 2.dp))
            }
            Chip(MockData.location)
        }

        Spacer(Modifier.height(18.dp))

        // "While you slept" hero -> Wealth
        JbCard(onClick = { onNavigate(Routes.WEALTH) }) {
            Column {
                Caption("While you slept")
                Text(MockData.totalWealth, style = WealthLarge, modifier = Modifier.padding(top = 6.dp, bottom = 4.dp))
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.NorthEast, null, tint = Up, modifier = Modifier.size(15.dp))
                        Spacer(Modifier.width(4.dp))
                        Text(MockData.overnightChange, color = Up, fontSize = 13.sp)
                    }
                    Sparkline(MockData.sparkline, Up, Modifier.width(92.dp).height(30.dp))
                }
            }
        }

        Spacer(Modifier.height(14.dp))

        // Today's note -> Insights
        JbCard(onClick = { onNavigate(Routes.INSIGHTS) }) {
            Column {
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Chip("Today's note", bg = AccentSoft, fg = Accent)
                    Caption("from research")
                }
                Text(MockData.insights[0].headline, color = Ink, fontSize = 15.sp, fontWeight = FontWeight.Medium, modifier = Modifier.padding(top = 8.dp))
                Text(MockData.insights[0].dek, color = InkSecondary, fontSize = 13.sp, modifier = Modifier.padding(top = 5.dp))
            }
        }

        Spacer(Modifier.height(14.dp))

        // Travel / FX card -> Card
        SoftCard(onClick = { onNavigate(Routes.CARD) }) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Outlined.Flight, null, tint = InkSecondary, modifier = Modifier.size(22.dp))
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("${MockData.tripCity} · ${MockData.tripWhen}", color = Ink, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                    Caption(MockData.tripCurrency, modifier = Modifier.padding(top = 1.dp))
                }
                Icon(Icons.AutoMirrored.Outlined.KeyboardArrowRight, null, tint = InkTertiary)
            }
        }

        Spacer(Modifier.height(18.dp))

        Row(Modifier.fillMaxWidth()) {
            QuickAction("Move", Icons.Outlined.SwapHoriz, Modifier.weight(1f)) { onNavigate(Routes.SEND) }
            QuickAction("Convert", Icons.Outlined.Refresh, Modifier.weight(1f)) { onNavigate(Routes.MOVE) }
            QuickAction("Card", Icons.Outlined.CreditCard, Modifier.weight(1f)) { onNavigate(Routes.CARD) }
            QuickAction("Concierge", Icons.Outlined.HeadsetMic, Modifier.weight(1f)) { onNavigate(Routes.CONCIERGE) }
        }
    }
}

@Composable
private fun QuickAction(label: String, icon: ImageVector, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Column(modifier.clickable { onClick() }, horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier.size(46.dp).clip(CircleShape).background(SurfaceMuted),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription = label, tint = Ink, modifier = Modifier.size(20.dp))
        }
        Spacer(Modifier.height(7.dp))
        Text(label, color = InkSecondary, fontSize = 11.sp)
    }
}
