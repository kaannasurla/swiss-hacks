package ch.juliusbaer.daybreak.ui.theme

import androidx.compose.ui.graphics.Color

// Ink / text
val Ink = Color(0xFF16223B)          // deep navy — primary text & wordmark
val InkSecondary = Color(0xFF5B6472) // muted body text
val InkTertiary = Color(0xFF9097A1)  // hints / captions

// Surfaces
val Paper = Color(0xFFF6F4EF)        // warm paper background (the "broadsheet" feel)
val SurfaceWhite = Color(0xFFFFFFFF) // cards
val SurfaceMuted = Color(0xFFF0EEE8) // soft cards / tracks
val Hairline = Color(0xFFE7E3DB)     // 0.5dp borders

// Brand accent
val Accent = Color(0xFF1F5FA5)       // refined blue — charts, info chips
val AccentSoft = Color(0xFFE6F0FA)

// Market semantics
val Up = Color(0xFF1D7D5B)
val UpSoft = Color(0xFFE3F1EA)
val Down = Color(0xFFB23B3B)
val DownSoft = Color(0xFFF6E7E5)
