package ch.juliusbaer.daybreak.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowForward
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ch.juliusbaer.daybreak.data.MockData
import ch.juliusbaer.daybreak.data.Wallet
import ch.juliusbaer.daybreak.ui.components.JbCard
import ch.juliusbaer.daybreak.ui.components.PrimaryButton
import ch.juliusbaer.daybreak.ui.components.SoftCard
import ch.juliusbaer.daybreak.ui.theme.Hairline
import ch.juliusbaer.daybreak.ui.theme.Ink
import ch.juliusbaer.daybreak.ui.theme.InkSecondary
import ch.juliusbaer.daybreak.ui.theme.InkTertiary
import ch.juliusbaer.daybreak.ui.theme.WealthMedium

@Composable
fun MoveScreen(onSend: () -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 22.dp)
            .padding(top = 12.dp, bottom = 24.dp)
    ) {
        Text("Your wallets", color = Ink, fontSize = 18.sp, fontWeight = FontWeight.Medium)
        Spacer(Modifier.height(14.dp))

        JbCard {
            Column {
                MockData.wallets.forEachIndexed { i, w ->
                    WalletRow(w, onClick = onSend)
                    if (i != MockData.wallets.lastIndex) HorizontalDivider(color = Hairline, thickness = 0.7.dp)
                }
            }
        }

        Spacer(Modifier.height(16.dp))
        PrimaryButton("Send money", onClick = onSend)

        Spacer(Modifier.height(16.dp))
        SoftCard {
            Column {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Convert", color = InkSecondary, fontSize = 13.sp)
                    Text(MockData.convertRate, color = InkSecondary, fontSize = 13.sp)
                }
                Row(Modifier.padding(top = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(MockData.convertFrom, style = WealthMedium, fontSize = 20.sp)
                    Spacer(Modifier.width(10.dp))
                    Icon(Icons.AutoMirrored.Outlined.ArrowForward, null, tint = InkTertiary, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(10.dp))
                    Text(MockData.convertTo, style = WealthMedium, fontSize = 20.sp)
                }
            }
        }

        Spacer(Modifier.height(16.dp))
        SoftCard {
            Row(
                Modifier.fillMaxWidth().heightIn(min = 70.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Bottom
            ) {
                Column {
                    Text("Julius Bär", color = InkSecondary, fontSize = 13.sp, letterSpacing = 2.sp)
                    Spacer(Modifier.height(20.dp))
                    Text(MockData.cardNumber, color = InkSecondary, fontSize = 14.sp, letterSpacing = 2.sp)
                }
                Text("auto-switches to local currency", color = InkTertiary, fontSize = 12.sp, modifier = Modifier.width(96.dp))
            }
        }
    }
}

@Composable
private fun WalletRow(w: Wallet, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.width(36.dp)) {
            Text(w.code, color = Ink, fontSize = 12.sp, fontWeight = FontWeight.Medium)
        }
        Text(w.name, color = InkSecondary, fontSize = 13.sp, modifier = Modifier.weight(1f))
        Text(w.balance, style = WealthMedium, fontSize = 15.sp)
    }
}
