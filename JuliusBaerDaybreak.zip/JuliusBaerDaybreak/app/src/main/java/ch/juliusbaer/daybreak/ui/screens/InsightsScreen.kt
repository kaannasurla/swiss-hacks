package ch.juliusbaer.daybreak.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ch.juliusbaer.daybreak.data.Article
import ch.juliusbaer.daybreak.data.MockData
import ch.juliusbaer.daybreak.ui.components.Caption
import ch.juliusbaer.daybreak.ui.components.Chip
import ch.juliusbaer.daybreak.ui.components.JbCard
import ch.juliusbaer.daybreak.ui.theme.AccentSoft
import ch.juliusbaer.daybreak.ui.theme.Accent
import ch.juliusbaer.daybreak.ui.theme.Ink
import ch.juliusbaer.daybreak.ui.theme.InkSecondary

@Composable
fun InsightsScreen(onOpenArticle: (Int) -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 22.dp)
            .padding(top = 12.dp, bottom = 24.dp)
    ) {
        Text("Written for you", color = Ink, fontSize = 18.sp, fontWeight = FontWeight.Medium)
        Caption("Your morning briefing, ${MockData.dateLabel}", modifier = Modifier.padding(top = 2.dp))
        Spacer(Modifier.height(16.dp))

        MockData.insights.forEachIndexed { i, article ->
            ArticleCard(article) { onOpenArticle(i) }
            if (i != MockData.insights.lastIndex) Spacer(Modifier.height(12.dp))
        }
    }
}

@Composable
private fun ArticleCard(article: Article, onClick: () -> Unit) {
    JbCard(onClick = onClick) {
        Column {
            Row(Modifier.fillMaxWidth(), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                Chip(article.tag, bg = AccentSoft, fg = Accent)
                Spacer(Modifier.weight(1f))
                Caption(article.time)
            }
            Text(
                article.headline,
                color = Ink,
                fontSize = 16.sp,
                fontWeight = FontWeight.Medium,
                modifier = Modifier.padding(top = 10.dp)
            )
            Text(
                article.dek,
                color = InkSecondary,
                fontSize = 13.sp,
                modifier = Modifier.padding(top = 5.dp)
            )
        }
    }
}
