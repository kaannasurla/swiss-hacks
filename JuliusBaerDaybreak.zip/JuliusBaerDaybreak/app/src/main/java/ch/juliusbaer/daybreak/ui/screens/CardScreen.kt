package ch.juliusbaer.daybreak.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CreditCard
import androidx.compose.material.icons.outlined.Flight
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ch.juliusbaer.daybreak.data.CardTx
import ch.juliusbaer.daybreak.data.MockData
import ch.juliusbaer.daybreak.ui.components.Caption
import ch.juliusbaer.daybreak.ui.components.JbCard
import ch.juliusbaer.daybreak.ui.components.ListRow
import ch.juliusbaer.daybreak.ui.components.SectionLabel
import ch.juliusbaer.daybreak.ui.theme.Accent
import ch.juliusbaer.daybreak.ui.theme.Hairline
import ch.juliusbaer.daybreak.ui.theme.Ink
import ch.juliusbaer.daybreak.ui.theme.InkSecondary
import ch.juliusbaer.daybreak.ui.theme.InkTertiary
import ch.juliusbaer.daybreak.ui.theme.SurfaceMuted
import ch.juliusbaer.daybreak.ui.theme.SurfaceWhite

@Composable
fun CardScreen() {
    var frozen by remember { mutableStateOf(false) }
    var travelMode by remember { mutableStateOf(true) }

    Column(
        Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 22.dp)
            .padding(top = 12.dp, bottom = 24.dp)
    ) {
        // Card visual
        Box(
            Modifier
                .fillMaxWidth()
                .height(190.dp)
                .clip(RoundedCornerShape(18.dp))
                .background(if (frozen) SurfaceMuted else SurfaceWhite)
                .padding(20.dp)
        ) {
            Column(Modifier.fillMaxWidth()) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Julius Bär", color = Ink, fontSize = 14.sp, letterSpacing = 2.5.sp)
                    Text("World", color = InkSecondary, fontSize = 12.sp)
                }
                Spacer(Modifier.height(48.dp))
                Text(MockData.cardNumber, color = Ink, fontSize = 16.sp, letterSpacing = 2.sp)
                Spacer(Modifier.height(16.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        Caption("Card holder")
                        Text(MockData.cardHolder, color = Ink, fontSize = 13.sp)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Caption("Expires")
                        Text(MockData.cardExpiry, color = Ink, fontSize = 13.sp)
                    }
                }
            }
        }

        if (frozen) {
            Spacer(Modifier.height(10.dp))
            Caption("Card frozen — purchases are paused", color = InkSecondary)
        }

        Spacer(Modifier.height(18.dp))

        // Controls
        JbCard {
            Column {
                ToggleRow(
                    title = "Freeze card",
                    subtitle = "Instantly pause all spending",
                    checked = frozen,
                    onToggle = { frozen = it }
                )
                HorizontalDivider(color = Hairline, thickness = 0.7.dp)
                ToggleRow(
                    title = "Travel mode",
                    subtitle = "Auto-switch to local currency",
                    checked = travelMode,
                    onToggle = { travelMode = it }
                )
            }
        }

        Spacer(Modifier.height(16.dp))

        JbCard {
            Column {
                ListRow("Spending limit", valueText = MockData.cardLimit, leading = Icons.Outlined.CreditCard)
                HorizontalDivider(color = Hairline, thickness = 0.7.dp)
                ListRow("Virtual card for travel", leading = Icons.Outlined.Flight)
                HorizontalDivider(color = Hairline, thickness = 0.7.dp)
                ListRow("Card details & PIN", leading = Icons.Outlined.Lock)
            }
        }

        Spacer(Modifier.height(18.dp))
        SectionLabel("Recent")
        Spacer(Modifier.height(12.dp))
        JbCard {
            Column {
                MockData.cardTransactions.forEachIndexed { i, t ->
                    TxRow(t)
                    if (i != MockData.cardTransactions.lastIndex) {
                        HorizontalDivider(color = Hairline, thickness = 0.7.dp)
                    }
                }
            }
        }
    }
}

@Composable
private fun ToggleRow(title: String, subtitle: String, checked: Boolean, onToggle: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Ink, fontSize = 14.sp)
            Caption(subtitle, modifier = Modifier.padding(top = 1.dp))
        }
        Switch(
            checked = checked,
            onCheckedChange = onToggle,
            colors = SwitchDefaults.colors(
                checkedThumbColor = SurfaceWhite,
                checkedTrackColor = Accent,
                uncheckedThumbColor = SurfaceWhite,
                uncheckedTrackColor = InkTertiary,
                uncheckedBorderColor = InkTertiary
            )
        )
    }
}

@Composable
private fun TxRow(t: CardTx) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(t.merchant, color = Ink, fontSize = 14.sp, fontWeight = FontWeight.Medium)
            Caption(if (t.pending) "${t.location} · pending" else t.location, modifier = Modifier.padding(top = 1.dp))
        }
        Text(t.amount, color = if (t.pending) InkTertiary else Ink, fontSize = 14.sp)
    }
}
