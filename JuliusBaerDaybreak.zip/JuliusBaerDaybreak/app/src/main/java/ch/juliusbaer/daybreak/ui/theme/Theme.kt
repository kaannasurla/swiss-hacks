package ch.juliusbaer.daybreak.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val JbColorScheme = lightColorScheme(
    primary = Accent,
    onPrimary = SurfaceWhite,
    primaryContainer = AccentSoft,
    onPrimaryContainer = Accent,
    background = Paper,
    onBackground = Ink,
    surface = SurfaceWhite,
    onSurface = Ink,
    surfaceVariant = SurfaceMuted,
    onSurfaceVariant = InkSecondary,
    outline = Hairline,
    outlineVariant = Hairline
)

@Composable
fun JuliusBaerTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = JbColorScheme,
        typography = AppTypography,
        content = content
    )
}
