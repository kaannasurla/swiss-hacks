package ch.juliusbaer.daybreak.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.Fingerprint
import androidx.compose.material.icons.outlined.HelpOutline
import androidx.compose.material.icons.outlined.Language
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ch.juliusbaer.daybreak.data.MockData
import ch.juliusbaer.daybreak.ui.components.Avatar
import ch.juliusbaer.daybreak.ui.components.Caption
import ch.juliusbaer.daybreak.ui.components.JbCard
import ch.juliusbaer.daybreak.ui.components.ListRow
import ch.juliusbaer.daybreak.ui.theme.Down
import ch.juliusbaer.daybreak.ui.theme.Hairline
import ch.juliusbaer.daybreak.ui.theme.Ink

@Composable
fun ProfileScreen(onSignOut: () -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 22.dp)
            .padding(top = 16.dp, bottom = 24.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Avatar(MockData.clientInitials, size = 56.dp)
            Spacer(Modifier.width(14.dp))
            Column {
                Text(MockData.clientFull, color = Ink, fontSize = 18.sp, fontWeight = FontWeight.Medium)
                Caption(MockData.clientSince, modifier = Modifier.padding(top = 2.dp))
                Caption("Your RM · ${MockData.rmName}")
            }
        }

        Spacer(Modifier.height(20.dp))

        JbCard {
            Column {
                ListRow("Personal details", leading = Icons.Outlined.Person)
                HorizontalDivider(color = Hairline, thickness = 0.7.dp)
                ListRow("Security & Face ID", leading = Icons.Outlined.Fingerprint)
                HorizontalDivider(color = Hairline, thickness = 0.7.dp)
                ListRow("Notifications", leading = Icons.Outlined.Notifications)
                HorizontalDivider(color = Hairline, thickness = 0.7.dp)
                ListRow("Language", valueText = "English", leading = Icons.Outlined.Language)
            }
        }

        Spacer(Modifier.height(14.dp))

        JbCard {
            Column {
                ListRow("Statements & documents", leading = Icons.Outlined.Description)
                HorizontalDivider(color = Hairline, thickness = 0.7.dp)
                ListRow("Help & contact", leading = Icons.Outlined.HelpOutline)
            }
        }

        Spacer(Modifier.height(20.dp))
        Text(
            "Sign out",
            color = Down,
            fontSize = 14.sp,
            fontWeight = FontWeight.Medium,
            modifier = Modifier
                .fillMaxWidth()
                .clickable { onSignOut() }
                .padding(8.dp)
        )
    }
}
