package ch.juliusbaer.daybreak.ui.navigation

/** Central place for all navigation routes. */
object Routes {
    const val DAYBREAK = "daybreak"
    const val WEALTH = "wealth"
    const val MOVE = "move"
    const val CONCIERGE = "concierge"

    const val SEND = "send"
    const val CARD = "card"
    const val INSIGHTS = "insights"
    const val PROFILE = "profile"

    const val ARTICLE_PATTERN = "article/{idx}"
    fun article(idx: Int) = "article/$idx"

    val topLevel = setOf(DAYBREAK, WEALTH, MOVE, CONCIERGE)
}
