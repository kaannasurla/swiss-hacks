package ch.juliusbaer.daybreak.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.NorthEast
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ch.juliusbaer.daybreak.data.MockData
import ch.juliusbaer.daybreak.ui.components.AllocationRow
import ch.juliusbaer.daybreak.ui.components.AreaChart
import ch.juliusbaer.daybreak.ui.components.Caption
import ch.juliusbaer.daybreak.ui.components.Chip
import ch.juliusbaer.daybreak.ui.components.SectionLabel
import ch.juliusbaer.daybreak.ui.theme.Accent
import ch.juliusbaer.daybreak.ui.theme.AccentSoft
import ch.juliusbaer.daybreak.ui.theme.Hairline
import ch.juliusbaer.daybreak.ui.theme.SurfaceWhite
import ch.juliusbaer.daybreak.ui.theme.Up
import ch.juliusbaer.daybreak.ui.theme.WealthLarge

@Composable
fun WealthScreen() {
    Column(
        Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 22.dp)
            .padding(top = 12.dp, bottom = 24.dp)
    ) {
        Caption("Total wealth")
        Text(
            MockData.totalWealth,
            style = WealthLarge,
            modifier = Modifier.padding(top = 5.dp, bottom = 3.dp)
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Outlined.NorthEast, null, tint = Up, modifier = Modifier.size(15.dp))
            Spacer(Modifier.width(4.dp))
            Text(MockData.yearChange, color = Up, fontSize = 13.sp)
        }

        Spacer(Modifier.height(16.dp))

        AreaChart(
            values = MockData.wealthSeries,
            lineColor = Accent,
            fillColor = AccentSoft,
            modifier = Modifier
                .fillMaxWidth()
                .height(120.dp)
        )

        Spacer(Modifier.height(12.dp))

        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center
        ) {
            RangeChip("1W", false)
            Spacer(Modifier.width(6.dp))
            RangeChip("1M", false)
            Spacer(Modifier.width(6.dp))
            RangeChip("1Y", true)
            Spacer(Modifier.width(6.dp))
            RangeChip("All", false)
        }

        Spacer(Modifier.height(18.dp))
        HorizontalDivider(color = Hairline, thickness = 0.7.dp)
        Spacer(Modifier.height(16.dp))

        SectionLabel("Allocation")
        Spacer(Modifier.height(12.dp))
        MockData.allocations.forEachIndexed { i, a ->
            AllocationRow(a)
            if (i != MockData.allocations.lastIndex) Spacer(Modifier.height(13.dp))
        }
    }
}

@Composable
private fun RangeChip(text: String, selected: Boolean) {
    if (selected) {
        Chip(text, bg = Accent, fg = SurfaceWhite)
    } else {
        Chip(text)
    }
}
