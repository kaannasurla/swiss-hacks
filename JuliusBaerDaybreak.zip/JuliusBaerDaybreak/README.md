# Julius Bär — Daybreak (Android concept)

A native Android prototype of the "Daybreak" private-banking app concept: a calm,
editorial morning-ritual experience rather than a dopamine feed. Built with Kotlin,
Jetpack Compose, Material 3, and Navigation Compose.

## Screens & flows
Top-level tabs (bottom navigation):
- **Daybreak** — morning briefing: overnight portfolio delta, a curated research note,
  and a calendar-aware travel/FX card. Every card is tappable and routes onward.
- **Wealth** — total wealth, a Canvas-drawn area chart, and allocation bars.
- **Move** — multi-currency wallets, a primary "Send money" action, and the FX convert module.
- **Concierge** — relationship manager, message thread, and quick requests.

Pushed destinations (with back navigation):
- **Send money** — three-step flow: pick recipient → enter amount on a custom keypad →
  review → confirmation success state.
- **Card** — card visual, freeze + travel-mode switches, spending limit, and recent transactions.
- **Insights** — a research feed; tapping a story opens the **Article** reader.
- **Article** — full reader with a "Discuss with Marco" action into Concierge.
- **Profile** — client details and settings, reached via the avatar in the top bar.

## Run it
1. Open the `JuliusBaerDaybreak` folder in **Android Studio** (Ladybug or newer).
2. Let it sync — Android Studio downloads the Gradle wrapper and dependencies.
3. Run the `app` configuration on an emulator or device (minSdk 26 / Android 8.0+).

## Project layout
```
app/src/main/java/ch/juliusbaer/daybreak/
  MainActivity.kt              // NavHost, top bar (back/avatar), bottom navigation
  data/MockData.kt             // sample data (replace with repositories)
  ui/navigation/Routes.kt      // central route constants
  ui/theme/                    // Color, Type (serif wealth figures), Theme
  ui/components/               // JbCard, PrimaryButton, ListRow, Avatar, Sparkline, AreaChart…
  ui/screens/                  // Daybreak, Wealth, Move, Concierge,
                               // SendMoney, Card, Insights, Article, Profile
```

## Architecture notes
- **Navigation:** top-level tabs use a single-top / save-restore-state pattern; detail screens
  are pushed onto the back stack. The top bar shows a back arrow on detail screens and the
  client avatar (→ Profile) on top-level screens. Routes live in `ui/navigation/Routes.kt`.
- **State:** the Send flow holds its step/recipient/amount in local Compose state. The natural
  next step is a `ViewModel` per flow backed by repositories for portfolio, FX, and CRM.
- **Brand:** the wordmark and palette are mode-adaptive placeholders. Swap in Julius Bär's
  official brand tokens and licensed typeface; keep the serif figures exactly.
- **Versions:** AGP 8.7.0, Kotlin 2.0.21, Compose BOM 2024.10.01, navigation-compose 2.8.3 are
  pinned to a known-good set — let Android Studio bump them to current and re-sync.
- **Theme:** light-only for now; a dark "obsidian" variant would slot in via a second ColorScheme.
